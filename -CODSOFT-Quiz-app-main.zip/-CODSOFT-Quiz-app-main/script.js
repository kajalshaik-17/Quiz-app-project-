const questions = [
{
question:"What does HTML stand for?",
answers:[
"Hyper Text Markup Language",
"High Text Machine Language",
"Home Tool Markup Language",
"Hyperlinks Text Markup Language"
],
correct:0
},
{
question:"Which language is used for styling web pages?",
answers:[
"HTML",
"Python",
"CSS",
"Java"
],
correct:2
},
{
question:"Which language is used for web interactivity?",
answers:[
"CSS",
"JavaScript",
"HTML",
"C"
],
correct:1
}
];

let currentQuestion = 0;
let score = 0;

const questionEl = document.getElementById("question");
const answersEl = document.getElementById("answers");
const nextBtn = document.getElementById("nextBtn");
const resultEl = document.getElementById("result");

function loadQuestion(){

const q = questions[currentQuestion];

questionEl.innerHTML =
`<h3>${q.question}</h3>`;

answersEl.innerHTML = "";

q.answers.forEach((answer,index)=>{

answersEl.innerHTML += `
<label class="answer">
<input type="radio" name="answer" value="${index}">
${answer}
</label>
`;

});

}

loadQuestion();

nextBtn.addEventListener("click",()=>{

const selected =
document.querySelector(
'input[name="answer"]:checked'
);

if(!selected){
alert("Please select an answer");
return;
}

if(
parseInt(selected.value) ===
questions[currentQuestion].correct
){
score++;
}

currentQuestion++;

if(currentQuestion < questions.length){

loadQuestion();

}else{

questionEl.style.display="none";
answersEl.style.display="none";
nextBtn.style.display="none";

resultEl.innerHTML =
`<h2>Your Score: ${score}/${questions.length}</h2>`;

}

});